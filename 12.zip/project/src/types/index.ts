export type DataCategory = 'air' | 'water' | 'temperature' | 'vegetation';

export interface DataPoint {
  id: string;
  label: string;
  value: number;
  timestamp: string;
  location: {
    lat: number;
    lng: number;
    name: string;
  };
  category: DataCategory;
}