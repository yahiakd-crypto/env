import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  LineChart, 
  PieChart, 
  Map, 
  Droplets, 
  Wind, 
  Thermometer, 
  Leaf, 
  Menu, 
  X,
  Download,
  Upload,
  Filter,
  RefreshCw
} from 'lucide-react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import DataCard from './components/DataCard';
import ChartContainer from './components/ChartContainer';
import MapView from './components/MapView';
import AuthModal from './components/AuthModal';
import { mockEnvironmentalData } from './data/mockData';
import { DataPoint, DataCategory } from './types';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeCategory, setActiveCategory] = useState<DataCategory>('air');
  const [data, setData] = useState<DataPoint[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('week');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(true);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');

  useEffect(() => {
    // Simulate data loading
    setIsLoading(true);
    setTimeout(() => {
      setData(mockEnvironmentalData.filter(item => item.category === activeCategory));
      setIsLoading(false);
    }, 800);
  }, [activeCategory, timeRange]);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleCategoryChange = (category: DataCategory) => {
    setActiveCategory(category);
  };

  const handleTimeRangeChange = (range: string) => {
    setTimeRange(range);
  };

  const handleLogin = (email: string, password: string) => {
    // In a real app, this would call an API to authenticate
    console.log('Logging in with:', email, password);
    setIsAuthenticated(true);
    setShowAuthModal(false);
  };

  const handleSignup = (name: string, email: string, password: string) => {
    // In a real app, this would call an API to register a new user
    console.log('Signing up with:', name, email, password);
    setIsAuthenticated(true);
    setShowAuthModal(false);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setShowAuthModal(true);
    setAuthMode('login');
  };

  const getAverageValue = () => {
    if (data.length === 0) return 0;
    return (data.reduce((sum, item) => sum + item.value, 0) / data.length).toFixed(1);
  };

  const getStatusColor = () => {
    const avg = parseFloat(getAverageValue());
    if (activeCategory === 'air') {
      return avg < 50 ? 'text-green-500' : avg < 100 ? 'text-yellow-500' : 'text-red-500';
    }
    if (activeCategory === 'water') {
      return avg < 3 ? 'text-green-500' : avg < 7 ? 'text-yellow-500' : 'text-red-500';
    }
    return avg < 25 ? 'text-green-500' : avg < 50 ? 'text-yellow-500' : 'text-red-500';
  };

  const getCategoryIcon = () => {
    switch (activeCategory) {
      case 'air':
        return <Wind className="h-8 w-8 text-blue-500" />;
      case 'water':
        return <Droplets className="h-8 w-8 text-blue-500" />;
      case 'temperature':
        return <Thermometer className="h-8 w-8 text-red-500" />;
      case 'vegetation':
        return <Leaf className="h-8 w-8 text-green-500" />;
      default:
        return <Wind className="h-8 w-8 text-blue-500" />;
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
        <AuthModal 
          isOpen={showAuthModal}
          mode={authMode}
          onLogin={handleLogin}
          onSignup={handleSignup}
          onToggleMode={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')}
        />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar 
        isOpen={sidebarOpen} 
        activeCategory={activeCategory}
        onCategoryChange={handleCategoryChange}
        onLogout={handleLogout}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          toggleSidebar={toggleSidebar} 
          sidebarOpen={sidebarOpen}
          timeRange={timeRange}
          onTimeRangeChange={handleTimeRangeChange}
        />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-800 flex items-center">
              {getCategoryIcon()}
              <span className="ml-2">
                {activeCategory.charAt(0).toUpperCase() + activeCategory.slice(1)} Quality Analysis
              </span>
            </h1>
            <p className="text-gray-600 mt-1">
              Environmental data visualization and analysis dashboard
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <DataCard 
              title="Average Quality" 
              value={getAverageValue()} 
              unit={activeCategory === 'temperature' ? '°C' : activeCategory === 'air' ? 'AQI' : 'ppm'}
              icon={getCategoryIcon()}
              statusColor={getStatusColor()}
            />
            <DataCard 
              title="Monitoring Stations" 
              value="24" 
              unit="active"
              icon={<Map className="h-6 w-6 text-indigo-500" />}
            />
            <DataCard 
              title="Data Points" 
              value={data.length.toString()} 
              unit="samples"
              icon={<BarChart3 className="h-6 w-6 text-purple-500" />}
            />
            <DataCard 
              title="Last Updated" 
              value="Just now" 
              unit=""
              icon={<RefreshCw className="h-6 w-6 text-teal-500" />}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <ChartContainer 
              title="Trend Analysis"
              className="lg:col-span-2"
              isLoading={isLoading}
              icon={<LineChart className="h-5 w-5" />}
              data={data}
              chartType="line"
            />
            <ChartContainer 
              title="Distribution"
              isLoading={isLoading}
              icon={<PieChart className="h-5 w-5" />}
              data={data}
              chartType="pie"
            />
          </div>

          <div className="grid grid-cols-1 gap-6">
            <MapView 
              title="Geographic Distribution"
              data={data}
              category={activeCategory}
              isLoading={isLoading}
            />
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;