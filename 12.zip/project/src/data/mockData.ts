import { DataPoint } from '../types';

// Generate random data points for demonstration
const generateMockData = (): DataPoint[] => {
  const categories = ['air', 'water', 'temperature', 'vegetation'];
  const locations = [
    { name: 'North Station', lat: 48.8566, lng: 2.3522 },
    { name: 'South Station', lat: 51.5074, lng: -0.1278 },
    { name: 'East Station', lat: 52.5200, lng: 13.4050 },
    { name: 'West Station', lat: 40.7128, lng: -74.0060 },
    { name: 'Central Station', lat: 35.6762, lng: 139.6503 },
  ];
  
  const data: DataPoint[] = [];
  
  // Generate data for the last 30 days
  for (let i = 0; i < 30; i++) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    // Generate data for each category
    categories.forEach(category => {
      // Generate 3-5 data points per day per category
      const pointsCount = Math.floor(Math.random() * 3) + 3;
      
      for (let j = 0; j < pointsCount; j++) {
        const location = locations[Math.floor(Math.random() * locations.length)];
        
        // Generate appropriate values based on category
        let value;
        switch (category) {
          case 'air':
            // Air quality index (0-300)
            value = Math.floor(Math.random() * 300);
            break;
          case 'water':
            // Water quality (0-10)
            value = Math.random() * 10;
            break;
          case 'temperature':
            // Temperature in Celsius (-10 to 40)
            value = Math.random() * 50 - 10;
            break;
          case 'vegetation':
            // Vegetation index (0-100)
            value = Math.floor(Math.random() * 100);
            break;
          default:
            value = Math.random() * 100;
        }
        
        data.push({
          id: `${category}-${i}-${j}`,
          label: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          value,
          timestamp: date.toISOString(),
          location: {
            ...location,
            // Add small random variation to location
            lat: location.lat + (Math.random() * 0.1 - 0.05),
            lng: location.lng + (Math.random() * 0.1 - 0.05),
          },
          category: category as any,
        });
      }
    });
  }
  
  return data;
};

export const mockEnvironmentalData = generateMockData();