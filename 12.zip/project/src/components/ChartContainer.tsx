import React, { ReactNode } from 'react';
import { LineChart, BarChart, PieChart } from 'lucide-react';
import { DataPoint } from '../types';

interface ChartContainerProps {
  title: string;
  icon: ReactNode;
  data: DataPoint[];
  chartType: 'line' | 'bar' | 'pie';
  className?: string;
  isLoading: boolean;
}

const ChartContainer: React.FC<ChartContainerProps> = ({ 
  title, 
  icon, 
  data, 
  chartType, 
  className = '',
  isLoading
}) => {
  const renderChart = () => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
        </div>
      );
    }

    // This is a placeholder for actual chart implementation
    // In a real app, you would use a charting library like Chart.js, Recharts, etc.
    if (chartType === 'line') {
      return (
        <div className="h-64 flex items-end space-x-2 pt-5">
          {data.slice(0, 12).map((point, index) => (
            <div key={index} className="flex-1 flex flex-col items-center">
              <div 
                className="w-full bg-emerald-500 rounded-t"
                style={{ height: `${(point.value / 150) * 100}%` }}
              ></div>
              <div className="text-xs text-gray-500 mt-1">{point.label.substring(0, 3)}</div>
            </div>
          ))}
        </div>
      );
    }

    if (chartType === 'pie') {
      return (
        <div className="h-64 flex items-center justify-center">
          <div className="relative w-40 h-40">
            <svg viewBox="0 0 100 100" className="w-full h-full">
              <circle cx="50" cy="50" r="40" fill="#10B981" />
              <circle cx="50" cy="50" r="30" fill="#34D399" />
              <circle cx="50" cy="50" r="20" fill="#6EE7B7" />
              <circle cx="50" cy="50" r="10" fill="#A7F3D0" />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center text-lg font-semibold text-gray-800">
              {data.length} points
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="h-64 flex items-center justify-center text-gray-500">
        Chart visualization will appear here
      </div>
    );
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-100 ${className}`}>
      <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center">
          <span className="text-gray-500 mr-2">{icon}</span>
          <h3 className="text-sm font-medium text-gray-700">{title}</h3>
        </div>
        <div className="flex space-x-2">
          <button className="p-1 text-gray-400 hover:text-gray-600 rounded">
            <LineChart className="h-4 w-4" />
          </button>
          <button className="p-1 text-gray-400 hover:text-gray-600 rounded">
            <BarChart className="h-4 w-4" />
          </button>
          <button className="p-1 text-gray-400 hover:text-gray-600 rounded">
            <PieChart className="h-4 w-4" />
          </button>
        </div>
      </div>
      <div className="p-5">
        {renderChart()}
      </div>
    </div>
  );
};

export default ChartContainer;