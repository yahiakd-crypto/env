import React, { ReactNode } from 'react';

interface DataCardProps {
  title: string;
  value: string;
  unit: string;
  icon: ReactNode;
  statusColor?: string;
}

const DataCard: React.FC<DataCardProps> = ({ title, value, unit, icon, statusColor = 'text-gray-800' }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <div className="text-gray-400">{icon}</div>
      </div>
      <div className="mt-2 flex items-baseline">
        <p className={`text-2xl font-semibold ${statusColor}`}>{value}</p>
        <p className="ml-1 text-sm text-gray-500">{unit}</p>
      </div>
    </div>
  );
};

export default DataCard;