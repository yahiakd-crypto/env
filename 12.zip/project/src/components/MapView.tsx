import React, { useState } from 'react';
import { Map, MapPin, Moon, Sun } from 'lucide-react';
import { DataPoint, DataCategory } from '../types';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

interface MapViewProps {
  title: string;
  data: DataPoint[];
  category: DataCategory;
  isLoading: boolean;
}

const MapView: React.FC<MapViewProps> = ({ title, data, category, isLoading }) => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [mapStyle, setMapStyle] = useState('standard');

  const getCategoryColor = () => {
    switch (category) {
      case 'air':
        return '#3B82F6';
      case 'water':
        return '#06B6D4';
      case 'temperature':
        return '#EF4444';
      case 'vegetation':
        return '#22C55E';
      default:
        return '#6B7280';
    }
  };

  const getMarkerSize = (value: number) => {
    return Math.max(8, Math.min(20, value / 10));
  };

  const getMapTileLayer = () => {
    if (isDarkMode) {
      return "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";
    }
    return "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
  };

  const getMapAttribution = () => {
    if (isDarkMode) {
      return '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>';
    }
    return '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
  };

  return (
    <div className={`${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-lg shadow-sm border border-gray-100 relative`}>
      {/* Pollution Background Overlay */}
      <div 
        className="absolute inset-0 opacity-15 pointer-events-none rounded-lg"
        style={{
          backgroundImage: `url(${
            isDarkMode 
              ? 'https://images.unsplash.com/photo-1569097242297-5a4d8b91fe4f?auto=format&fit=crop&q=80'
              : 'https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?auto=format&fit=crop&q=80'
          })`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          mixBlendMode: isDarkMode ? 'color-dodge' : 'multiply'
        }}
      />

      <div className={`px-5 py-4 border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-100'} flex items-center justify-between relative z-10`}>
        <div className="flex items-center">
          <span className={isDarkMode ? 'text-gray-300' : 'text-gray-500'}>
            <Map className="h-5 w-5 mr-2" />
          </span>
          <h3 className={`text-sm font-medium ${isDarkMode ? 'text-gray-100' : 'text-gray-700'}`}>
            {title}
          </h3>
        </div>
        <div className="flex items-center space-x-3">
          <select 
            className={`text-sm rounded-md shadow-sm focus:ring focus:ring-opacity-50 ${
              isDarkMode 
                ? 'bg-gray-800 border-gray-700 text-gray-100 focus:border-emerald-500 focus:ring-emerald-400' 
                : 'border-gray-300 focus:border-emerald-300 focus:ring-emerald-200'
            }`}
            value={mapStyle}
            onChange={(e) => setMapStyle(e.target.value)}
          >
            <option value="standard">Standard</option>
            <option value="satellite">Satellite</option>
            <option value="terrain">Terrain</option>
          </select>
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`p-2 rounded-md transition-colors ${
              isDarkMode 
                ? 'bg-gray-800 text-yellow-400 hover:bg-gray-700' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
        </div>
      </div>

      <div className="p-5 relative z-10">
        {isLoading ? (
          <div className="flex items-center justify-center h-96">
            <div className={`animate-spin rounded-full h-12 w-12 border-b-2 ${
              isDarkMode ? 'border-emerald-400' : 'border-emerald-500'
            }`}></div>
          </div>
        ) : (
          <div className="h-96 rounded-lg overflow-hidden">
            <MapContainer
              center={[20, 0]}
              zoom={2}
              style={{ height: '100%', width: '100%' }}
              className="z-0"
            >
              <TileLayer
                attribution={getMapAttribution()}
                url={getMapTileLayer()}
              />
              {data.map((point) => (
                <CircleMarker
                  key={point.id}
                  center={[point.location.lat, point.location.lng]}
                  radius={getMarkerSize(point.value)}
                  fillColor={getCategoryColor()}
                  color={getCategoryColor()}
                  weight={1}
                  opacity={0.8}
                  fillOpacity={0.6}
                >
                  <Popup>
                    <div className="p-2">
                      <h4 className="font-medium text-gray-900">{point.location.name}</h4>
                      <p className="text-sm text-gray-600">
                        Value: {point.value.toFixed(2)}
                        {category === 'temperature' ? '°C' : category === 'air' ? ' AQI' : ' ppm'}
                      </p>
                      <p className="text-xs text-gray-500">{point.label}</p>
                    </div>
                  </Popup>
                </CircleMarker>
              ))}
            </MapContainer>
            
            <div className={`absolute bottom-8 left-8 p-3 rounded-lg shadow-md ${
              isDarkMode ? 'bg-gray-800 text-gray-100' : 'bg-white text-gray-700'
            }`}>
              <h4 className="text-sm font-medium mb-1">Legend</h4>
              <div className="flex items-center space-x-4 text-xs">
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-green-500 mr-1"></div>
                  <span>Good</span>
                </div>
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-yellow-500 mr-1"></div>
                  <span>Moderate</span>
                </div>
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-red-500 mr-1"></div>
                  <span>Poor</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MapView;