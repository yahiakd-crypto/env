import React from 'react';
import { Wind, Droplets, Thermometer, Leaf, BarChart3, Settings, HelpCircle, LogOut } from 'lucide-react';
import { DataCategory } from '../types';

interface SidebarProps {
  isOpen: boolean;
  activeCategory: DataCategory;
  onCategoryChange: (category: DataCategory) => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, activeCategory, onCategoryChange, onLogout }) => {
  const categories = [
    { id: 'air' as DataCategory, name: 'Air Quality', icon: <Wind /> },
    { id: 'water' as DataCategory, name: 'Water Quality', icon: <Droplets /> },
    { id: 'temperature' as DataCategory, name: 'Temperature', icon: <Thermometer /> },
    { id: 'vegetation' as DataCategory, name: 'Vegetation', icon: <Leaf /> },
  ];

  return (
    <div className={`bg-white border-r border-gray-200 transition-all duration-300 ${isOpen ? 'w-64' : 'w-0 -ml-64'} md:ml-0 fixed md:relative h-full z-30`}>
      <div className="flex flex-col h-full">
        <div className="flex items-center justify-center h-16 border-b border-gray-200">
          <BarChart3 className="h-8 w-8 text-emerald-600" />
          <span className="ml-2 text-xl font-semibold text-gray-800">EcoViz</span>
        </div>
        
        <div className="flex-1 overflow-y-auto py-4">
          <div className="px-4 mb-6">
            <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Data Categories
            </h2>
            <nav className="mt-2 space-y-1">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => onCategoryChange(category.id)}
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md w-full ${
                    activeCategory === category.id
                      ? 'bg-emerald-50 text-emerald-700'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <span className={`mr-3 ${activeCategory === category.id ? 'text-emerald-500' : 'text-gray-400'}`}>
                    {category.icon}
                  </span>
                  {category.name}
                </button>
              ))}
            </nav>
          </div>
          
          <div className="px-4">
            <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Settings
            </h2>
            <nav className="mt-2 space-y-1">
              <button className="flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900 w-full">
                <Settings className="mr-3 text-gray-400" />
                Preferences
              </button>
              <button className="flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900 w-full">
                <HelpCircle className="mr-3 text-gray-400" />
                Help & Support
              </button>
            </nav>
          </div>
        </div>
        
        <div className="p-4 border-t border-gray-200">
          <button 
            onClick={onLogout}
            className="flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900 w-full"
          >
            <LogOut className="mr-3 text-gray-400" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;