import React, { useState } from 'react';
import { BarChart3, Mail, Lock, User, ArrowRight, CheckCircle, Moon, Sun } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface AuthModalProps {
  isOpen: boolean;
  mode: 'login' | 'signup';
  onLogin: (email: string, password: string) => void;
  onSignup: (name: string, email: string, password: string) => void;
  onToggleMode: () => void;
}

const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  mode,
  onLogin,
  onSignup,
  onToggleMode,
}) => {
  const { isDarkMode, toggleDarkMode } = useTheme();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      if (mode === 'signup') {
        if (!name) {
          setError('Name is required');
          setIsLoading(false);
          return;
        }
        if (password !== confirmPassword) {
          setError('Passwords do not match');
          setIsLoading(false);
          return;
        }
        onSignup(name, email, password);
      } else {
        onLogin(email, password);
      }
    }, 800);
  };

  if (!isOpen) return null;

  return (
    <div className={`flex flex-col md:flex-row h-full md:h-auto w-full max-w-4xl rounded-xl shadow-2xl overflow-hidden transition-colors ${isDarkMode ? 'bg-gray-900' : 'bg-white'}`}>
      {/* Left side - Branding and info */}
      <div className="relative md:w-2/5 bg-emerald-600 p-8 flex flex-col justify-between text-white overflow-hidden">
        {/* Background Image Overlay */}
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `url(${isDarkMode 
              ? 'https://images.unsplash.com/photo-1584267385494-9fdd9a71ad75?auto=format&fit=crop&q=80'
              : 'https://images.unsplash.com/photo-1498925008800-019c7d59d903?auto=format&fit=crop&q=80'
            })`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            mixBlendMode: 'overlay'
          }}
        />
        
        <div className="relative z-10">
          <div className="flex items-center mb-6">
            <BarChart3 className="h-10 w-10 mr-3" />
            <h2 className="text-3xl font-bold">EcoViz</h2>
          </div>
          <h3 className="text-xl font-medium mb-6">Environmental Monitoring Dashboard</h3>
          <p className="text-emerald-100 mb-8">
            Access real-time environmental data visualization and analysis tools to monitor air quality, 
            water quality, temperature trends, and vegetation health.
          </p>
        </div>
        
        <div className="space-y-3 relative z-10">
          <div className="flex items-center">
            <CheckCircle className="h-5 w-5 mr-2 text-emerald-300" />
            <span className="text-sm">Real-time data visualization</span>
          </div>
          <div className="flex items-center">
            <CheckCircle className="h-5 w-5 mr-2 text-emerald-300" />
            <span className="text-sm">Interactive geographic mapping</span>
          </div>
          <div className="flex items-center">
            <CheckCircle className="h-5 w-5 mr-2 text-emerald-300" />
            <span className="text-sm">Trend analysis and reporting</span>
          </div>
        </div>
      </div>

      {/* Right side - Auth form */}
      <div className={`w-full md:w-3/5 p-8 md:p-12 ${isDarkMode ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <BarChart3 className={`h-10 w-10 mr-3 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-600'}`} />
            <h2 className={`text-2xl font-bold ${isDarkMode ? 'text-gray-100' : 'text-gray-800'}`}>EcoViz</h2>
          </div>
          <button
            onClick={toggleDarkMode}
            className={`p-2 rounded-md transition-colors ${
              isDarkMode 
                ? 'bg-gray-800 text-yellow-400 hover:bg-gray-700' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
        </div>

        <h3 className={`text-2xl font-bold mb-2 ${isDarkMode ? 'text-gray-100' : 'text-gray-800'}`}>
          {mode === 'login' ? 'Welcome back' : 'Create your account'}
        </h3>
        <p className={`mb-8 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
          {mode === 'login' 
            ? 'Sign in to access your environmental dashboard' 
            : 'Join us to start monitoring environmental data'}
        </p>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500 text-red-700 rounded-md text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {mode === 'signup' && (
            <div>
              <label htmlFor="name" className={`block text-sm font-medium mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                Full Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className={`h-5 w-5 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                </div>
                <input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`pl-10 w-full py-3 px-4 rounded-lg focus:outline-none focus:ring-2 transition-colors ${
                    isDarkMode 
                      ? 'bg-gray-800 border-gray-700 text-gray-100 focus:ring-emerald-500 focus:border-emerald-500' 
                      : 'border border-gray-300 focus:ring-emerald-200 focus:border-emerald-300'
                  }`}
                  placeholder="John Doe"
                />
              </div>
            </div>
          )}

          <div>
            <label htmlFor="email" className={`block text-sm font-medium mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Email Address
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className={`h-5 w-5 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`} />
              </div>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`pl-10 w-full py-3 px-4 rounded-lg focus:outline-none focus:ring-2 transition-colors ${
                  isDarkMode 
                    ? 'bg-gray-800 border-gray-700 text-gray-100 focus:ring-emerald-500 focus:border-emerald-500' 
                    : 'border border-gray-300 focus:ring-emerald-200 focus:border-emerald-300'
                }`}
                placeholder="you@example.com"
                required
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="password" className={`block text-sm font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                Password
              </label>
              {mode === 'login' && (
                <button type="button" className={`text-sm ${isDarkMode ? 'text-emerald-400 hover:text-emerald-300' : 'text-emerald-600 hover:text-emerald-500'} transition-colors`}>
                  Forgot password?
                </button>
              )}
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className={`h-5 w-5 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`} />
              </div>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`pl-10 w-full py-3 px-4 rounded-lg focus:outline-none focus:ring-2 transition-colors ${
                  isDarkMode 
                    ? 'bg-gray-800 border-gray-700 text-gray-100 focus:ring-emerald-500 focus:border-emerald-500' 
                    : 'border border-gray-300 focus:ring-emerald-200 focus:border-emerald-300'
                }`}
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          {mode === 'signup' && (
            <div>
              <label htmlFor="confirmPassword" className={`block text-sm font-medium mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                Confirm Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className={`h-5 w-5 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                </div>
                <input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className={`pl-10 w-full py-3 px-4 rounded-lg focus:outline-none focus:ring-2 transition-colors ${
                    isDarkMode 
                      ? 'bg-gray-800 border-gray-700 text-gray-100 focus:ring-emerald-500 focus:border-emerald-500' 
                      : 'border border-gray-300 focus:ring-emerald-200 focus:border-emerald-300'
                  }`}
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className={`w-full flex justify-center items-center py-3 px-4 rounded-lg shadow-sm text-base font-medium text-white transition-colors ${
              isDarkMode
                ? 'bg-emerald-500 hover:bg-emerald-600 focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-emerald-500'
                : 'bg-emerald-600 hover:bg-emerald-700 focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500'
            } disabled:opacity-70 disabled:cursor-not-allowed`}
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {mode === 'login' ? 'Signing in...' : 'Creating account...'}
              </>
            ) : (
              <>
                {mode === 'login' ? 'Sign In' : 'Create Account'}
                <ArrowRight className="ml-2 h-5 w-5" />
              </>
            )}
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            {mode === 'login' ? "Don't have an account?" : "Already have an account?"}
            <button
              type="button"
              onClick={onToggleMode}
              className={`ml-2 font-medium ${isDarkMode ? 'text-emerald-400 hover:text-emerald-300' : 'text-emerald-600 hover:text-emerald-500'} transition-colors`}
            >
              {mode === 'login' ? 'Sign up now' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;